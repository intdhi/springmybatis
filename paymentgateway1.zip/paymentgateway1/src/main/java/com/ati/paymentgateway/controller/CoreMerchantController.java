package com.ati.paymentgateway.controller;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ati.paymentgateway.model.Merchant;
import com.ati.paymentgateway.service.MerchantService;

@Controller
@RequestMapping("core/merchant")
public class CoreMerchantController extends BaseFormController{
	@Autowired 
	private MerchantService merchantService;
	private static final Logger logger = Logger.getLogger(CoreMerchantController.class);

	@RequestMapping(value= "")
	public String listMerchant(Model model) throws Exception{
		List<Merchant> list = merchantService.getAllMerchant();
		model.addAttribute("merchat", list);
		if (logger.isDebugEnabled()){
			logger.debug(list);
		}
		return "merchant/list";
	}
	
	@RequestMapping(value= "/detail/{id}", method = RequestMethod.GET)
	public String detailMerchant(Model model,@PathVariable(value = "id") Long id) throws Exception{
		Merchant merchant= merchantService.getMerchant(id);
		model.addAttribute("merchant", merchant);
		if (logger.isDebugEnabled()){
			logger.debug("get : "+merchant);
		}
		return "merchant/detail";
	}
	

	@RequestMapping(value="/add", method = RequestMethod.GET)
	public String addMerchant(Model model ) throws Exception{
		Merchant merchant= new Merchant();
		model.addAttribute("merchant", merchant);
		if (logger.isDebugEnabled()){
			logger.debug("get : "+merchant);
		}
		return "merchant/add";
	}

	@RequestMapping(value="/add", method=RequestMethod.POST)
	public String addmer(Model model, @Validated Merchant merchant, BindingResult errors,
			HttpServletRequest request,HttpServletResponse response) {
		if (request.getParameter("cancel") != null) {
			return "redirect:/core/merchant";
		}
		if (errors.hasErrors()){
			model.addAttribute("merchant", merchant);
			saveError(request, getText("something wrong", merchant.getMerchantName(), request.getLocale()));
			logger.error(merchant);
			return "merchant/add";
		}
		merchantService.insertMerchant(merchant);
		saveMessage(request, getText("success save", merchant.getMerchantName(), request.getLocale()));
		if (logger.isDebugEnabled()){
			logger.debug("insert : "+merchant);
		}
		return "redirect:/core/merchant";
	}
	
	@RequestMapping(value="/delete/{id}", method = RequestMethod.GET)
	public String deleteMerchant(Model model,@PathVariable(value = "id") Long id ) throws Exception{
		Merchant merchant= merchantService.getMerchant(id);
		model.addAttribute("merchant", merchant);
		if (logger.isDebugEnabled()){
			logger.debug("get : "+merchant);
		}
		return "merchant/delete";
	}
	
	@RequestMapping(value="/delete/{id}", method=RequestMethod.POST)
	public String deleteMerchant2(Model model, @Validated Merchant merchant
			, BindingResult errors,
			HttpServletRequest request,HttpServletResponse response) {		
		if (request.getParameter("cancel") != null) {
			return "redirect:/core/merchant";
		}
		if (errors.hasErrors()){
			Merchant merchant2=  merchantService.getMerchant(merchant.getId());
			model.addAttribute("merchant", merchant2);
			saveError(request, getText("something wrong", merchant.getMerchantName(),
					  request.getLocale()));
			logger.error(errors);
			return "merchant/delete";
		}
		merchantService.deleteMerchant(merchant.getId());
		saveMessage(request, getText("merchant.deleted", merchant.getMerchantName(), 
				request.getLocale()));
		if (logger.isDebugEnabled()){
			logger.debug("delete : "+merchant);
		}
		return "redirect:/core/merchant";
	}
	
	@RequestMapping(value="/edit/{id}", method = RequestMethod.GET)
	public String editMerchant(Model model,@PathVariable(value = "id") Long id ) throws Exception{
		Merchant merchant= merchantService.getMerchant(id);
		model.addAttribute("merchant", merchant);
		if (logger.isDebugEnabled()){
			logger.debug("get : "+merchant);
		}
		return "merchant/edit";
	}
	
	
	@RequestMapping(value="/edit/{id}", method=RequestMethod.POST)
	public String editMerchant2(Model model, @Validated Merchant merchant
			,BindingResult errors,
			HttpServletRequest request,HttpServletResponse response) {		
		if (request.getParameter("cancel") != null) {
			return "redirect:/core/merchant";
		}
		if (errors.hasErrors()){
			Merchant merchant2=  merchantService.getMerchant(merchant.getId());
			model.addAttribute("merchant", merchant2);
			saveError(request, getText("something wrong", merchant.getMerchantName(),
					  request.getLocale()));
			logger.error(errors);
			return "merchant/edit";
		}
		merchantService.updateMerchant(merchant);
		saveMessage(request, getText("merchant.edit", merchant.getMerchantName(), 
				request.getLocale()));
		if (logger.isDebugEnabled()){
			logger.debug("edit : "+merchant);
		}
		return "redirect:/core/merchant";
	}
}
