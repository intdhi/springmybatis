package com.ati.paymentgateway.test;

import com.ati.paymentgateway.model.Merchant;

public class test {
	public static void main(String[] args) {
		Merchant aa = new Merchant();
		aa.setId(1L);
		aa.setMerchantName("aa");
		aa.setMerchantType("aa");
		aa.setTerminalName("aa");
		
		
		//aa.setActivateDateTime();
	}
}
